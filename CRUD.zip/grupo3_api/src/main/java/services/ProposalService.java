package services;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.ws.rs.core.Response.Status;

import model.Proposal;
@Path("/proposal")
@Consumes(value=MediaType.APPLICATION_JSON)
@Produces(value=MediaType.APPLICATION_JSON)

public class ProposalService {
	
	
	@Path("{id}")
	@GET
	public static Response getProposal(@PathParam("id") int idProposal) throws ClassNotFoundException{
		List<Proposal> proposals = new ArrayList<>();
		Connection conn = null;
		Proposal proposal = new Proposal();
		Class.forName("org.sqlite.JDBC");
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			
			String sql = "Select * FROM Proposal WHERE id=?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, idProposal);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				proposal.setId(rs.getInt("id"));
				proposal.setTitle(rs.getString("title"));
				proposal.setUser_id(rs.getInt("user_id"));
				proposal.setCreated_at(rs.getString("created_at"));
				proposals.add(proposal);
			}
			rs.close();
            stmt.close();
            conn.close();
            
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.ok(proposals,MediaType.APPLICATION_JSON).build();
	}
	
	@Path("total")
	@GET
	public static Response getTotalProposal() throws ClassNotFoundException{
		List<Proposal> proposals = new ArrayList<>();
		Connection conn = null;
		Proposal proposal = new Proposal();
		Class.forName("org.sqlite.JDBC");
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			
			String sql = "Select * FROM Proposal";
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				proposal.setId(rs.getInt("id"));
				proposal.setTitle(rs.getString("title"));
				proposal.setUser_id(rs.getInt("user_id"));
				proposal.setCreated_at(rs.getString("created_at"));
				proposals.add(proposal);
			}
			rs.close();
            stmt.close();
            conn.close();
            
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.ok(proposals.size(),MediaType.APPLICATION_JSON).build();
	}
	
	@DELETE
	@Path("{id}")
	public static Response deleteProposal(@PathParam("id") int idProposal) throws ClassNotFoundException{
		Connection conn = null;
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "DELETE FROM Proposal WHERE id=?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, idProposal);
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Propuesta no encontrada").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Propuesta eliminada").build();
	}
	
	@POST
	public static Response createProposal(Proposal proposal) throws ClassNotFoundException{
		Connection conn = null;
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "INSERT INTO Proposal (id, title, user_id, created_at) VALUES (?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, proposal.getId());
			stmt.setString(2, proposal.getTitle());
			stmt.setInt(3, proposal.getUser_id());
			stmt.setString(4, proposal.getCreated_at());
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Propuesta no añadida").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Propuesta Añadida").build();
	}
	
	@PUT
	@Path("{id}")
	public static Response updateProposal(@PathParam("id") int idProposal,Proposal proposal) throws ClassNotFoundException{
		Connection conn = null;
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "UPDATE Proposal SET id = ?, title = ?, user_id = ?, created_at = ? WHERE id = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, proposal.getId());
			stmt.setString(2, proposal.getTitle());
			stmt.setInt(3, proposal.getUser_id());
			stmt.setString(4, proposal.getCreated_at());
			stmt.setInt(5, idProposal);
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Propuesta no encontrada").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Propuesta Actualizada").build();
	}
}

