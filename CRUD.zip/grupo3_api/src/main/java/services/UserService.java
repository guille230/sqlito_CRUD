package services;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.ws.rs.core.Response.Status;

import model.User;
@Path("/user")
@Consumes(value=MediaType.APPLICATION_JSON)
@Produces(value=MediaType.APPLICATION_JSON)

public class UserService {
	
	
	@Path("{name}/{password}")
	@GET
	public static Response getUser(@PathParam("name") String username,@PathParam("password") String pass) throws ClassNotFoundException{
		List<User> users = new ArrayList<>();
		Connection conn = null;
		User user = new User();
		Class.forName("org.sqlite.JDBC");
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			
			String sql = "Select * FROM User WHERE name=? AND password=?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, username);
	 		stmt.setString(2, pass);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setPassword(rs.getString("password"));
				user.setActive(rs.getInt("active"));
				user.setCreated_at(rs.getString("created_at"));
				users.add(user);
			}
			rs.close();
            stmt.close();
            conn.close();
            
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.ok(users,MediaType.APPLICATION_JSON).build();
	}
	
	@Path("total")
	@GET
	public static Response getTotalUser() throws ClassNotFoundException{
		List<User> users = new ArrayList<>();
		Connection conn = null;
		User user = new User();
		Class.forName("org.sqlite.JDBC");
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			
			String sql = "Select * FROM User";
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setPassword(rs.getString("password"));
				user.setActive(rs.getInt("active"));
				user.setCreated_at(rs.getString("created_at"));
				users.add(user);
			}
			rs.close();
            stmt.close();
            conn.close();
            
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.ok(users.size(),MediaType.APPLICATION_JSON).build();
	}
	
	
	@DELETE
	@Path("{name}")
	public static Response deleteUser(@PathParam("name") String username) throws ClassNotFoundException{
		Connection conn = null;
		User user = new User();
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "DELETE FROM User WHERE name=?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, username);
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Usuario no encontrado").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Usuario eliminado").build();
	}
	
	@POST
	public static Response createUser(User user) throws ClassNotFoundException{
		Connection conn = null;
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "INSERT INTO User (id, name, password, active, created_at) VALUES (?,?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, user.getId());
			stmt.setString(2, user.getName());
			stmt.setString(3, user.getPassword());
			stmt.setInt(4, user.getActive());
			stmt.setString(5, user.getCreated_at());
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Usuario no Añadido").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Usuario Añadido").build();
	}
	
	@PUT
	@Path("{id}")
	public static Response updateUser(@PathParam("id") int idUser,User user) throws ClassNotFoundException{
		Connection conn = null;
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "UPDATE User SET id = ?, name = ?, password = ?, active = ?, created_at = ? WHERE id = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, user.getId());
			stmt.setString(2, user.getName());
			stmt.setString(3, user.getPassword());
			stmt.setInt(4, user.getActive());
			stmt.setString(5, user.getCreated_at());
			stmt.setInt(6, idUser);
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Usuario no Añadido").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Usuario Añadido").build();
	}
}

