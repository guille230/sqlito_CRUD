package services;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.ws.rs.core.Response.Status;

import model.Comment;
@Path("/comment")
@Consumes(value=MediaType.APPLICATION_JSON)
@Produces(value=MediaType.APPLICATION_JSON)

public class CommentService {
	
	
	@Path("{id}")
	@GET
	public static Response getComment(@PathParam("id") int idComment) throws ClassNotFoundException{
		List<Comment> comments = new ArrayList<>();
		Connection conn = null;
		Comment comment = new Comment();
		Class.forName("org.sqlite.JDBC");
		int count =0;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			
			String sql = "Select * FROM Comment WHERE id=?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, idComment);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				comment.setId(rs.getInt("id"));
				comment.setProposal_id(rs.getInt("proposal_id"));
				comment.setParent_id(rs.getInt("parent_id"));
				comment.setUser_id(rs.getInt("user_id"));
				comment.setBody(rs.getString("body"));
				comment.setCreated_at(rs.getString("created_at"));
				comments.add(comment);
			}
			rs.close();
            stmt.close();
            conn.close();
            
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.ok(comments,MediaType.APPLICATION_JSON).build();
	}
	
	@Path("total")
	@GET
	public static Response getTotalComment() throws ClassNotFoundException{
		List<Comment> comments = new ArrayList<>();
		Connection conn = null;
		Comment comment = new Comment();
		Class.forName("org.sqlite.JDBC");
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			
			String sql = "Select * FROM Comment";
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				comment.setId(rs.getInt("id"));
				comment.setProposal_id(rs.getInt("proposal_id"));
				comment.setParent_id(rs.getInt("parent_id"));
				comment.setUser_id(rs.getInt("user_id"));
				comment.setBody(rs.getString("body"));
				comment.setCreated_at(rs.getString("created_at"));
				comments.add(comment);
			}
			rs.close();
            stmt.close();
            conn.close();
            
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.ok(comments.size(),MediaType.APPLICATION_JSON).build();
	}
	
	
	@DELETE
	@Path("{id}")
	public static Response deleteComment(@PathParam("id") int idComment) throws ClassNotFoundException{
		Connection conn = null;
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "DELETE FROM Comment WHERE id=?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, idComment);
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Comentario no encontrado").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Comentario eliminado").build();
	}
	
	@POST
	public static Response createComment(Comment comment) throws ClassNotFoundException{
		Connection conn = null;
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "INSERT INTO Comment (id, proposal_id, parent_id, user_id, body,created_at) VALUES (?,?,?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, comment.getId());
			stmt.setInt(2, comment.getProposal_id());
			stmt.setInt(3, comment.getParent_id());
			stmt.setInt(4, comment.getUser_id());
			stmt.setString(5, comment.getBody());
			stmt.setString(6, comment.getCreated_at());
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Comentario no añadido").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Comentario añadido").build();
	}
	
	@PUT
	@Path("{id}")
	public static Response updateComment(@PathParam("id") int idComment,Comment comment) throws ClassNotFoundException{
		Connection conn = null;
		Class.forName("org.sqlite.JDBC");
		int result;
		try {
			//Database location
			String url = "jdbc:sqlite:/home/tsi/Escritorio/API_REST_IN_PEACE/grupo3.db";
			//create connection
			conn = DriverManager.getConnection(url);
			String sql = "UPDATE or REPLACE Comment SET id = ?, proposal_id = ?, parent_id = ?, user_id = ?, body = ?, created_at = ? WHERE id = ?";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, comment.getId());
			stmt.setInt(2, comment.getProposal_id());
			stmt.setInt(3, comment.getParent_id());
			stmt.setInt(4, comment.getUser_id());
			stmt.setString(5, comment.getBody());
			stmt.setString(6, comment.getCreated_at());
			stmt.setInt(7, idComment);
			result = stmt.executeUpdate();
			stmt.close();
            conn.close();
            if(result==0) {
            	return Response.status(Status.BAD_REQUEST).entity("Comentario no encontrado ").build();
            }
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return Response.status(Status.BAD_REQUEST).entity("Comentario Actualizado").build();
	}
}

