package model;

public class Proposal {
	int id;
	String  title;
	int user_id;
	String created_at;
	
	
	
	public Proposal() {
		super();
	}

	public Proposal(int id, String title, int user_id, String created_at) {
		super();
		this.id = id;
		this.title = title;
		this.user_id = user_id;
		this.created_at = created_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	
	
}
