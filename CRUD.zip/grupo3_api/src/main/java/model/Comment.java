package model;

public class Comment {
	int id;
	int proposal_id;
	int parent_id;
	int user_id;
	String body;
	String created_at;
	
	
	
	public Comment() {
		super();
	}

	public Comment(int id, int proposal_id, int parent_id, int user_id, String body, String created_at) {
		super();
		this.id = id;
		this.proposal_id = proposal_id;
		this.parent_id = parent_id;
		this.user_id = user_id;
		this.body = body;
		this.created_at = created_at;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProposal_id() {
		return proposal_id;
	}

	public void setProposal_id(int proposal_id) {
		this.proposal_id = proposal_id;
	}

	public int getParent_id() {
		return parent_id;
	}

	public void setParent_id(int id_parent) {
		this.parent_id = id_parent;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	
	
}
