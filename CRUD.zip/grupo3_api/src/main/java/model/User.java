package model;

public class User {
	int id;
	String name;
	String password;
	int active;
	String created_at;
	
	
	public User() {
		super();
	}


	


	public User(int id, String name, String password, int active, String created_at) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.active = active;
		this.created_at = created_at;
	}





	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public int getActive() {
		return active;
	}


	public void setActive(int active) {
		this.active = active;
	}

	

	public String getCreated_at() {
		return created_at;
	}





	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}





	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", password=" + password + ", active=" + active + "]";
	}
	
	
}
