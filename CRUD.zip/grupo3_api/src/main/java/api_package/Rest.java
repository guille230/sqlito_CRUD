package api_package;
import javax.ws.rs.*;
import javax.ws.rs.core.*; 
	
	@ApplicationPath("/") 
	public class Rest extends Application { 
		
	}


